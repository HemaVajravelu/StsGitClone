define(
"dijit/_editor/nls/pl/LinkDialog", ({
	createLinkTitle: "Właściwości odsyłacza",
	insertImageTitle: "Właściwości obrazu",
	url: "Adres URL:",
	text: "Opis:",
	target: "Docelowe:",
	set: "Ustaw",
	currentWindow: "Bieżące okno",
	parentWindow: "Okno macierzyste",
	topWindow: "Okno najwyższego poziomu",
	newWindow: "Nowe okno"
})
);
