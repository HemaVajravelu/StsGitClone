//>>built
define("dijit/_editor/nls/sr/LinkDialog",{createLinkTitle:"Svojstva linka",insertImageTitle:"Svojstva slike",url:"URL:",text:"Opis:",target:"Cilj:",set:"Podesi:",currentWindow:"Aktuelni prozor",parentWindow:"Nadređeni prozor",topWindow:"Najviši prozor",newWindow:"Novi prozor"});
